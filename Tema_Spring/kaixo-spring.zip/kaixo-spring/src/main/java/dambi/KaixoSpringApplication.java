package dambi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KaixoSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(KaixoSpringApplication.class, args);
	}

}
